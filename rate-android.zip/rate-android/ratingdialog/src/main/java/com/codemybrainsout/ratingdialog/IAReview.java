package com.codemybrainsout.ratingdialog;

import android.app.Activity;
import android.content.Context;

import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.review.model.ReviewErrorCode;
import com.google.android.play.core.tasks.Task;

public class IAReview {
    private static volatile IAReview INSTANCE;
    public static synchronized IAReview getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new IAReview();
        }
        return INSTANCE;
    }

    ReviewManager manager;
    ReviewInfo reviewInfo;

    public void initIAReview(Activity context){
         manager = ReviewManagerFactory.create(context);
        Task<ReviewInfo> request = manager.requestReviewFlow();
        request.addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                // We can get the ReviewInfo object
                reviewInfo = task.getResult();

                Task<Void> flow = manager.launchReviewFlow(context, reviewInfo);
                flow.addOnCompleteListener(task2 -> {
                    // The flow has finished. The API does not indicate whether the user
                    // reviewed or not, or even whether the review dialog was shown. Thus, no
                    // matter the result, we continue our app flow.
                });

            } else {
                // There was some problem, log or handle the error code.
                String reviewErrorCode = task.getException().toString();
            }
        });
    }


    public void showInAppReview(Activity activity){

    }
}
